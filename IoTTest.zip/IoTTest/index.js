console.log('Loading function');

var doc = require('dynamodb-doc');
var dynamo = new doc.DynamoDB();
var mysql = require('mysql');
var aws = require('aws-sdk');

exports.handler = function(event, context) {
    console.log('Received event:', JSON.stringify(event, null, 2));

};
